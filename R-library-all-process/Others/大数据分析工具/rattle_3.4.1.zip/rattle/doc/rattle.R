### R code from vignette source 'rattle.Rnw'

###################################################
### code chunk number 1: install (eval = FALSE)
###################################################
## install.packages(rattle, dependencies=c("Depends", "Suggests"))


###################################################
### code chunk number 2: start_up (eval = FALSE)
###################################################
## library(rattle)
## rattle()


